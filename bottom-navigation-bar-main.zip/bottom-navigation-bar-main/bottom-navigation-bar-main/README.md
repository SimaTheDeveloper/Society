# Bottom Navigation Bar With Expandable Menu
## [Watch it on youtube](https://youtu.be/xSVZm6TRogE)
### Bottom Navigation Bar With Expandable Menu

- Bottom Navigation Bar With Expandable Menu Using HTML CSS And JavaScript
- Contains a navigation bar with link icons.
- Contains a circular button that expands a menu with links.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/@Bedimcode)

![preview img](/preview.png)
